package com.tyler.app.planewar;

public class UtilityHelper
{
	public static int SCREEN_HEIGHT ;
	public static int SCREEN_WIDTH;
}
